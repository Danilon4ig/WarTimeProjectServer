This is a add-on Adds some Firearm for Vic's Point Blank Mods
這是一個為 Vic's Point Blank 模組添加槍枝的追加包

If Google Translate results are bad, delete file from here:
如果翻譯的結果不好，請從此處刪除文件：
[VPB]_ROC-Pack_Vx.x.x\assets\pointblank\lang

Vic's Point Blank Mods Curseforge
https://www.curseforge.com/minecraft/mc-mods/vics-point-blank

Vic's Point Blank Mods Discord Server
https://discord.com/invite/U5EkncgjYc


追加包的Curseforge / Add-on Curseforge
https://www.curseforge.com/minecraft/customization/vics-point-blank-roc-pack

追加包的Discord / Add-on Discord Server
https://discord.com/invite/NTZY5PMSdf